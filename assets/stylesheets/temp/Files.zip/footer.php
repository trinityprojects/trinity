
    <div class="col-12  p-10">
        <div class="footer">
            <div class="social-media">
            Social Media Accounts:
            <br /> 	&nbsp; &nbsp;
            <a href="https://www.facebook.com" target="_blank"> <img src="assets/images/facebook-logo.png" target="_blank"></img></a>
            <a href="https://www.twitter.com" target="_blank"> <img src="assets/images/twitter-logo.png" target="_blank"></img></a>
            </div>
            Copyright © <?php echo $_SESSION['organizationName']; ?>.
            All rights reserved.
            <br />
            <p>
                <em>ADDRESS: </em>
                <?php echo $_SESSION['organizationAddress']; ?>
                <br />
                <em>TEL. NO.: </em>
                <?php echo $_SESSION['organizationContactNumber']; ?>
                <em>WEBSITE: </em>
                <?php echo $_SESSION['organizationalWebSite']; ?>
            </p>

        </div><!-- <div class="footer">-->
    </div><!--<div class="col-12  p-10">-->
</div> <!--<div class="row">-->
</body>
